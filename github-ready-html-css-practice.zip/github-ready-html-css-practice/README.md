# HTML & CSS Practice Files

This folder contains separate HTML/CSS practice exercises with unique filenames.

## Files

1. `amazon-layout-practice.html` + `amazon-layout-practice.css`
2. `responsive-media-query.html` + `responsive-media-query.css`
3. `flexbox-navbar-center.html` + `flexbox-navbar-center.css`
4. `fixed-position-box.html` + `fixed-position-box.css`
5. `amazon-navbar-practice.html` + `amazon-navbar-practice.css`
6. `css-typography-practice.html` + `css-typography-practice.css`
7. `css-specificity-practice.html` + `css-specificity-practice.css`

Each HTML file already links to its corresponding renamed CSS file.
